/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snakegameGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;

public class SnakeGameGUI extends JPanel implements ActionListener {

    private static final int TILE_SIZE = 20; //Oyun tahtası boyutu
    private static final int WIDTH = 20;
    private static final int HEIGHT = 20;
    private static final int DELAY = 150; //Oyun döngüsünün gecikme süresi (milisaniye cinsinden), yani her hamlenin ne kadar sürede bir yapılacağı.

    private ArrayList<SnakePart> snake; //yılanın parçaları
    private int[][] board;//0boş 1yılan 2yemek
    private int foodX;
    private int foodY;
    private char direction;
    private boolean isGameOver;
    private int score;
    private JButton restartButton;

    public SnakeGameGUI() {
        setPreferredSize(new Dimension(WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE));//Panelin boyutunu ayarlar.
        setBackground(Color.WHITE);
        setFocusable(true);//Panele odaklanabilirlik ekler. Böylece klavye girişlerini alabiliriz.
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e.getKeyCode());
            }
        });

        restartButton = new JButton("Restart");
        restartButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                isGameOver = false;
                initializeGame();
                restartButton.setVisible(false); // Oyun yeniden başladığında düğmeyi gizle
            }
        });
        restartButton.setVisible(false); // Başlangıçta düğmeyi gizle
        add(restartButton);

        initializeGame();
        Timer timer = new Timer(DELAY, this);
        timer.start();
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        requestFocusInWindow();
    }

    private void initializeGame() {
        snake = new ArrayList<>();
        snake.add(new SnakePart(5, 5)); // Initial snake position
        board = new int[WIDTH][HEIGHT];
        direction = 'R'; // Initial direction (right)
        spawnFood();
        isGameOver = false;
        score = 0;
    }

    private void spawnFood() {
        Random random = new Random();
        int x, y;
        do {
            x = random.nextInt(WIDTH);
            y = random.nextInt(HEIGHT);
        } while (board[x][y] != 0);

        foodX = x;
        foodY = y;
        board[x][y] = 2;
    }

    private void handleKeyPress(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_W:
                if (direction != 'D') {
                    direction = 'U';
                }
                break;
            case KeyEvent.VK_S:
                if (direction != 'U') {
                    direction = 'D';
                }
                break;
            case KeyEvent.VK_A:
                if (direction != 'R') {
                    direction = 'L';
                }
                break;
            case KeyEvent.VK_D:
                if (direction != 'L') {
                    direction = 'R';
                }
                break;
        }
    }

    private void move() {
        if (!isGameOver) {
            SnakePart head = snake.get(0);
            SnakePart newHead = new SnakePart(head);

            switch (direction) {
                case 'U':
                    newHead.y--;
                    break;
                case 'D':
                    newHead.y++;
                    break;
                case 'L':
                    newHead.x--;
                    break;
                case 'R':
                    newHead.x++;
                    break;
            }

            if (newHead.equals(foodX, foodY)) {
                snake.add(0, newHead);
                score += 10;
                spawnFood();
            } else {
                snake.add(0, newHead);
                SnakePart tail = snake.remove(snake.size() - 1);
                board[tail.x][tail.y] = 0;
            }

            if (checkCollision(newHead)) {
                isGameOver = true;
            }
        }
    }

    private boolean checkCollision(SnakePart head) {
        if (head.x < 0 || head.x >= WIDTH || head.y < 0 || head.y >= HEIGHT) {
            return true;
        }

        for (int i = 1; i < snake.size(); i++) {
            if (head.equals(snake.get(i))) {
                return true;
            }
        }

        // Yılanın başının kendi vücuduyla çarpışmasını kontrol et
        for (int i = 1; i < snake.size(); i++) {
            SnakePart part = snake.get(i);
            if (head.equals(part.x, part.y)) {
                return true;
            }
        }

        return false;
    }

    private void draw(Graphics g) {
        if (!isGameOver) {
            // Satır ve sütunlar şeklinde ızgara çiz
            g.setColor(Color.LIGHT_GRAY);
            for (int x = 0; x < WIDTH; x++) {
                g.drawLine(x * TILE_SIZE, 0, x * TILE_SIZE, HEIGHT * TILE_SIZE);
            }
            for (int y = 0; y < HEIGHT; y++) {
                g.drawLine(0, y * TILE_SIZE, WIDTH * TILE_SIZE, y * TILE_SIZE);
            }

            // Draw food
            g.setColor(Color.RED);
            g.fillRect(foodX * TILE_SIZE, foodY * TILE_SIZE, TILE_SIZE, TILE_SIZE);

            // Draw snake
            for (int i = 0; i < snake.size(); i++) {
                SnakePart part = snake.get(i);
                if (i == 0) {
                    // Yılanın başı büyük yuvarlak
                    g.setColor(Color.GREEN);
                    g.fillOval(part.x * TILE_SIZE, part.y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                } else {
                    // Yılanın kuyruğu küçük yuvarlak
                    g.setColor(Color.GREEN);
                    g.fillOval(part.x * TILE_SIZE + TILE_SIZE / 4, part.y * TILE_SIZE + TILE_SIZE / 4, TILE_SIZE / 2, TILE_SIZE / 2);
                }
            }

            // Draw score
            g.setColor(Color.BLACK);
            g.drawString("Score: " + score, 10, 20);
        } else {
            // Game over message
            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 24));
            String gameOverMsg = "Game Over - Score: " + score;
            int msgWidth = g.getFontMetrics().stringWidth(gameOverMsg);
            g.drawString(gameOverMsg, (WIDTH * TILE_SIZE - msgWidth) / 2, HEIGHT * TILE_SIZE / 2);

            restartButton.setVisible(true);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!isGameOver) {
            move();
        }
        repaint();
    }

    private class SnakePart {

        int x, y;

        SnakePart(int x, int y) {
            this.x = x;
            this.y = y;
        }

        SnakePart(SnakePart other) {
            this.x = other.x;
            this.y = other.y;
        }

        boolean equals(int x, int y) {
            return this.x == x && this.y == y;
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Snake Game");
        SnakeGameGUI game = new SnakeGameGUI();
        frame.add(game);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
