/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package snakegame;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Yağmur BAŞOĞLU
 */
public class SnakeGame {

    private int height = 10;
    private int width = 10;
    private char emptCell = ',';
    private char snakeHead = '0';
    private char snakeBody = 'o';
    private char food = '*';

    private ArrayList<Integer> snakeX;
    private ArrayList<Integer> snakeY;
    private int foodX;
    private int foodY;
    private char[][] board;
    private char direction;
    private boolean isGameOver;
    private int score;
    Scanner scanner = new Scanner(System.in);

    public SnakeGame() {
        this.snakeX = new ArrayList<>();
        this.snakeY = new ArrayList<>();
        this.board = new char[height][width];
        this.direction = ' ';
        this.isGameOver = false;
        this.score = 0;
        initializeBoard();
        spawnFood();
        // Starting position of the snake
        int initialX = height / 2;
        int initialY = width / 2;
        snakeX.add(initialX);
        snakeY.add(initialY);
    }

    private void initializeBoard() {
        for (int row = 0; row < height; row++) {
            for (int col = 0; col < width; col++) {
                board[row][col] = emptCell;
            }
        }
    }

    private void spawnFood() {
        Random random = new Random();
        int row, col;
        do {
            row = random.nextInt(height);
            col = random.nextInt(width);
        } while (board[row][col] != emptCell);

        foodX = row;
        foodY = col;
        board[row][col] = food;
    }

    private void move() {
        // Calculate the new position of the snake's head
        int newHeadX = snakeX.get(0);
        int newHeadY = snakeY.get(0);

        switch (this.direction) {
            case 'U':
                newHeadX--;
                break;
            case 'D':
                newHeadX++;
                break;
            case 'L':
                newHeadY--;
                break;
            case 'R':
                newHeadY++;
                break;
            default:
                break;
        }

        // Add the position of the new head to the head of the snake
        snakeX.add(0, newHeadX);
        snakeY.add(0, newHeadY);
        // Check the snake's length and trim its tail if hasn't eaten food
        if (newHeadX == foodX && newHeadY == foodY) {
            spawnFood();
            score += 10;
        } else {
            snakeX.remove(snakeX.size() - 1);
            snakeY.remove(snakeY.size() - 1);

        }

        System.out.println("Score: " + score);
    }

    private void displayBoard() {
        for (int row = 0; row < height; row++) {
            for (int col = 0; col < width; col++) {
                char cell = emptCell;
                if (row == foodX && col == foodY) {
                    cell = food;
                } else if (row == snakeX.get(0) && col == snakeY.get(0)) {
                    cell = snakeHead;
                } else {
                    boolean isSnakePart = false;
                    for (int i = 1; i < snakeX.size(); i++) {
                        if (row == snakeX.get(i) && col == snakeY.get(i)) {
                            cell = snakeBody;
                            isSnakePart = true;
                            break;
                        }
                    }
                    if (!isSnakePart) {
                        cell = emptCell;
                    }
                }
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }

    private void getInput() {
        boolean validInput = false;
        while (!validInput) {
            // Enter the user input here.
            String newDirection = scanner.next();
            switch (newDirection.toLowerCase()) {
                case "w":
                    this.direction = 'U';
                    validInput = true;
                    break;
                case "s":
                    this.direction = 'D';
                    validInput = true;
                    break;
                case "a":
                    this.direction = 'L';
                    validInput = true;
                    break;
                case "d":
                    this.direction = 'R';
                    validInput = true;
                    break;
                default:
                    System.out.println("Invalid input. Please use 'W', 'A', 'S', or 'D' for movement.");
                    break;
            }
        }
    }

    private void checkCollision() {
        // Collision checking will be handled here.
        int headX = snakeX.get(0);
        int headY = snakeY.get(0);

        // Boundary collision check
        if (headX < 0 || headX >= height || headY < 0 || headY >= width) {
            isGameOver = true;
            return;
        }

        //Self collision check
        for (int i = 1; i < snakeX.size(); i++) {
            if (headX == snakeX.get(i) && headY == snakeY.get(i)) {
                isGameOver = true;
                return;
            }
        }

    }

    public void playGame() {
        while (!isGameOver) {
            displayBoard();
            getInput();
            move();
            checkCollision();
        }
        choise();
    }

    public void choise() {
        System.out.println("Game Over! Score: " + score);
        boolean validChoice = false;
        while (!validChoice) {
            System.out.println("Would you like to play again? (Y/N): ");
            String choice = scanner.next();

            if (choice.equalsIgnoreCase("Y")) {
                SnakeGame game = new SnakeGame();
                game.playGame();
                validChoice = true; // Geçerli bir seçenek girildi
            } else if (choice.equalsIgnoreCase("N")) {
                System.out.println("Thanks.. See you again..");
                validChoice = true; // Geçerli bir seçenek girildi
            } else {
                System.out.println("Please enter 'Y' or 'N'!");
            }
        }
    }

    public static void main(String[] args) {
        SnakeGame game = new SnakeGame();
        game.playGame();
    }
}
